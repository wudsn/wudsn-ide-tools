#ifndef YYSTYPE
#define YYSTYPE int
#endif


extern YYSTYPE yylval;
