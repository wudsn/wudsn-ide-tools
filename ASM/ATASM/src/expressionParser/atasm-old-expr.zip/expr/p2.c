#include <string.h>
#include <stdio.h>
#include <ctype.h>

char *E(char *str);
int error(char *err, int tp);

int stack[64];
int top;

/*=========================================================================*/
int push(int v) {
  if (top==64) {
    error("Stack overflow evaluating expression",1);
  }
  stack[top]=v;
  top++;
}
/*=========================================================================*/
int pop() {
  if (!top) {
    error("Stack underflow evaluating expression",1);
  }
  top--;
  return stack[top];
}
/*=========================================================================*/
char *F(char *str) {
  char buf[10], *walk;
  int v;
  
  if (*str=='[') {
    str++;
    str=E(str);
    if (*str==']') {
      str++;
    } else {
      error("Mismatched braces in expression",1);
    }
  } else {
    walk=buf;
    *walk=0;
    while(*str=='-')
      *walk++=*str++;
    if (isdigit(*str)) {
      while(isdigit(*str)) {
	*walk++=*str++;
      }
      *walk=0;
    } else {
      error("Error in expression",1);
    }
    sscanf(buf,"%d",&v);
    push(v);
  }
  return str;
}
/*=========================================================================*/
char *TP(char *str) {
  int a,b;
  char c;
  if ((*str=='*')||(*str=='/')) {
    c=*str;
    str++;
    str=F(str);
    str=TP(str);
    b=pop();
    a=pop();
    if (c=='*')
      push(a*b);
    else
      push(a/b);
  }
  return str;
}
/*=========================================================================*/
char *T(char *str) {
  str=F(str);
  str=TP(str);
  return str;
}
/*=========================================================================*/
char *AP(char *str) {
  int a,b;
  char c;
  if ((*str=='+')||(*str=='-')) {
    c=*str;
    str++;
    str=T(str);
    str=AP(str);
    b=pop();
    a=pop();
    if (c=='+')
      push(a+b);
    else
      push(a-b);
  }
  return str;
}
/*=========================================================================*/
char *A(char *str) {
  str=T(str);
  str=AP(str);
  return str;
}
/*=========================================================================*/
char *EP(char *str) {
  int a,b;
  char c;
  if ((*str=='&')||(*str=='|')||(*str=='^')) {
    c=*str;
    str++;
    str=A(str);
    str=EP(str);
    b=pop();
    a=pop();
    if (c=='&')
      push(a&b);
    else if (c=='|')
      push(a|b);
    else 
      push(a^b);
  }
  return str;
}
/*=========================================================================*/
char *E(char *str) {
  str=A(str);
  str=EP(str);
  return str;
}
/*=========================================================================*/
char *last_op(char *top, char *cur) {
  cur--;
  
  while(isdigit(*cur)&&(cur!=top))
    cur--;
  if (cur==top)
    return NULL;
  else
    return cur;
}
/*=========================================================================*/
int parse_expr(char *a) {
  int v,c,i,n;
  char *str,*walk,*look;
  char buf[80],work[80];
  char *math[3]={"*/","+-","&|^"};
  char *imath[3]={"+-&|^[]","*/&|^[]","+-*/[]"};

  strcpy(work,a);
  
  for(n=0;n<3;n++) {
    walk=buf;
    look=strpbrk(work,math[n]);
    if (look) {
      *walk=0;
      strcpy(work,buf);
      printf("Mod: %s\n",buf);
    }
  }
  strcat(buf,"$");

  printf("Mod: %s\n",buf);
  top=0;

  str=E(buf);
  if (strcmp(str,"$")) {
    error("Error in expression",1);
  }
  return pop();
}
/*=========================================================================*/
