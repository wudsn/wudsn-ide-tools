#include <string.h>
#include <stdio.h>
#include <ctype.h>

int error(char *err, int tp);

int stack[64],values[64],nums[64];
int top;
/*=========================================================================*/
int push(int v,int t) {
  if (top==64) {
    error("Stack overflow evaluating expression",1);
  }
  stack[top]=v;
  values[top]=t;
  top++;
}
/*=========================================================================*/
int empty() {
  return (top==0);
}
/*=========================================================================*/
int look() {
  if (!top)
    error("Stack underflow evaluating expression",1);
  
  return stack[top-1];
}
/*=========================================================================*/
int pop(int *t) {
  if (!top) {
    error("Stack underflow evaluating expression",1);
  }
  top--;
  *t=values[top];
  return stack[top];
}
/*=========================================================================*/
int evaluate(char *a) {
  char *term="N$*/+-[]";
  char c;
  int e,v,num,curval;
  int vstack[64], vtop;
  
  vtop=num=0;
  printf("\n");
  while(!empty()) {
    c=look();
    if (strchr(term,c)) {  /* Terminal symbol */
      if (c==*a) {
	pop(&curval);
	a++;
      } else {
	error("Error evaluating expression.",1);
      }
    } else {
      e=0;
      switch(c) {
      case 'E':
	if ((*a=='N')||(*a=='(')) {
	  pop(&curval);
	  push('e',curval);
	  push('T',curval);
	  v=curval;
	} else e=1;      
	break;
      case 'e':
	if (*a=='+') {
	  printf("+ ");
	  pop(&curval);
	  v=v+curval;
	  push('e',v);
	  push('T',v);
	  push('+',0);
	} else if ((*a==')')||(*a=='$')) {
	  pop(&curval);
	} else e=1;
	break;
      case 'T':
	if ((*a=='N')||(*a=='(')) {
	  pop(&curval);
	  push('t',curval);
	  push('F',curval);
	} else e=1;      
	break;
      case 't':
	if ((*a=='+')||(*a==')')||(*a=='$')) {
	  pop(&curval);
	} else if (*a=='*') {
	  printf("* ");
	  pop(&curval);
	  v=v*curval;
	  push('t',v);
	  push('F',v);
	  push('*',0);
	} else e=1;
	break;
      case 'F':
	if (*a=='N') {
	  pop(&curval);
	  curval=nums[num++];
	  printf("N(%d) ",curval);
	  push('N',curval);
	} else if (*a=='(') {	 
	  pop(&curval);
	  push(')',0);
	  push('E',curval);
	  push('(',0);
	} else e=1;
	break;
      default:
	e=1;
      }
      if (e)
	error("Error parsing expression.",1);
    }
  }
  printf("\n<%d>\n",v);
  return 0;
}
/*=========================================================================*/
int parse_expr(char *a) {
  int v,num;
  char expr[80], *look, *walk, *n;
  
  top=num=0;
  push('$',0);
  push('E',0);
  look=a;
  walk=expr;
  while(*look) {
    if (isdigit(*look)) {
      *walk++='N';
      n=walk;
      while(isdigit(*look))
	*n++=*look++;
      *n=0;
      sscanf(walk,"%d",&v);
      nums[num]=v;
      num++;
    } else *walk++=*look++;
  }
  *walk++='$';
  *walk=0;
  printf("Evaluting: %s\n",expr);
  
  v=evaluate(expr);
  return v;
}
/*=========================================================================*/
